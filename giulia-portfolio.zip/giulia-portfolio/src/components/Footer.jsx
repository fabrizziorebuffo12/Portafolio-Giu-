export default function Footer() {
  return (
    <footer className="footer">
      <span>GA.GA</span>
      <span>Interior designer</span>
      <span>Based in Ccs, Venezuela</span>
      <span>2026</span>
      <a href="mailto:contact@giulianaagazzillodesign.com">Contact</a>
      <a
        href="https://giulianaagazzillodesign.com"
        target="_blank"
        rel="noreferrer"
      >
        giulianaagazzillodesign.com
      </a>
    </footer>
  )
}
