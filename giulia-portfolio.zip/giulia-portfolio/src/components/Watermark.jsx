export default function Watermark() {
  return (
    <div className="watermark" aria-hidden="true">
      Giulia
    </div>
  )
}
