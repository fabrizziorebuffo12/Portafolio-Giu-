export default function Nav() {
  return (
    <nav className="nav">
      <a href="/about" className="nav__link">
        About me
      </a>
      <span className="nav__year">2026</span>
    </nav>
  )
}
