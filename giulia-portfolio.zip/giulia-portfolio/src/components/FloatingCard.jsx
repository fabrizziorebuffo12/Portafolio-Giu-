import { useState } from 'react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'

export default function FloatingCard({
  project,
  index,
  isDimmed,
  onHoverStart,
  onHoverEnd,
}) {
  const navigate = useNavigate()
  const [cursorPos, setCursorPos] = useState({ x: 0, y: 0 })
  const [showCursor, setShowCursor] = useState(false)

  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect()
    setCursorPos({ x: e.clientX - rect.left, y: e.clientY - rect.top })
  }

  return (
    <motion.div
      className="floating-card"
      style={{
        width: project.size,
        height: project.size,
        top: project.top,
        left: project.left,
      }}
      initial={{ opacity: 0, scale: 0.85, rotate: project.rotate }}
      animate={{
        opacity: isDimmed ? 0.45 : 1,
        scale: 1,
        rotate: project.rotate,
      }}
      transition={{
        opacity: { duration: 0.3, ease: 'easeOut' },
        scale: {
          duration: 0.6,
          delay: index * 0.12,
          ease: 'easeOut',
        },
      }}
      whileHover={{
        scale: 1.12,
        rotate: 0,
        zIndex: 20,
        transition: { duration: 0.35, ease: 'easeOut' },
      }}
      onMouseEnter={() => {
        onHoverStart(project.id)
        setShowCursor(true)
      }}
      onMouseLeave={() => {
        onHoverEnd()
        setShowCursor(false)
      }}
      onMouseMove={handleMouseMove}
      onClick={() => navigate(`/proyecto/${project.id}`)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter') navigate(`/proyecto/${project.id}`)
      }}
    >
      <img src={project.image} alt={project.alt} className="floating-card__img" />
      <span className="floating-card__title">{project.title}</span>

      {showCursor && (
        <span
          className="custom-cursor"
          style={{ left: cursorPos.x, top: cursorPos.y }}
        />
      )}
    </motion.div>
  )
}
