import { useParams, Link } from 'react-router-dom'

// Placeholder: esta vista se construye en un prompt aparte.
// Por ahora solo confirma que la navegación desde una FloatingCard funciona.
export default function ProjectDetail() {
  const { id } = useParams()

  return (
    <div style={{ padding: '4rem', fontFamily: 'Helvetica Neue, Helvetica, Arial, sans-serif' }}>
      <p>Vista de detalle del proyecto {id} — pendiente de construir.</p>
      <Link to="/">Volver al home</Link>
    </div>
  )
}
