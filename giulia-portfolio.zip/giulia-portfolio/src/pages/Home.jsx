import { useState } from 'react'
import Watermark from '../components/Watermark.jsx'
import Nav from '../components/Nav.jsx'
import FloatingCard from '../components/FloatingCard.jsx'
import Footer from '../components/Footer.jsx'
import projects from '../data/projects.js'

export default function Home() {
  const [hoveredId, setHoveredId] = useState(null)

  return (
    <div className="home">
      <Watermark />
      <Nav />

      <div className="cards-canvas">
        {projects.map((project, index) => (
          <FloatingCard
            key={project.id}
            project={project}
            index={index}
            isDimmed={hoveredId !== null && hoveredId !== project.id}
            onHoverStart={setHoveredId}
            onHoverEnd={() => setHoveredId(null)}
          />
        ))}
      </div>

      <Footer />
    </div>
  )
}
