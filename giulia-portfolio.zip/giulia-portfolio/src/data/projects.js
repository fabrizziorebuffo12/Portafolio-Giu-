// Posiciones, tamaños y rotación FIJOS (no aleatorios) para que el
// layout sea consistente entre visitas. Los valores de top/left están
// pensados para un lienzo de referencia de ~1440px de ancho; al agregar
// responsive, conviene pasar estos a % o clamp().
//
// Todas las imágenes son de Unsplash (Unsplash License, uso libre,
// ninguna es "Unsplash+"), referenciadas directo desde este archivo.

const projects = [
  {
    id: 1,
    title: 'Proyecto 1',
    image:
      'https://images.unsplash.com/photo-1759238136854-a43787126db7?q=80&w=900&auto=format&fit=crop',
    alt: 'Sala de estar minimalista, tonos cálidos',
    size: 334,
    top: '8%',
    left: '6%',
    rotate: -4,
  },
  {
    id: 2,
    title: 'Proyecto 2',
    image:
      'https://images.unsplash.com/photo-1750420556288-d0e32a6f517b?q=80&w=900&auto=format&fit=crop',
    alt: 'Cuarto minimalista, tonos neutros',
    size: 334,
    top: '4%',
    left: '38%',
    rotate: 3,
  },
  {
    id: 3,
    title: 'Proyecto 3',
    image:
      'https://images.unsplash.com/photo-1764526624453-db32c24eca55?q=80&w=900&auto=format&fit=crop',
    alt: 'Cocina minimalista, madera clara',
    size: 390,
    top: '10%',
    left: '66%',
    rotate: -2,
  },
  {
    id: 4,
    title: 'Proyecto 4',
    image:
      'https://images.unsplash.com/photo-1704428381342-ea9df943619e?q=80&w=900&auto=format&fit=crop',
    alt: 'Baño minimalista, piedra natural',
    size: 238,
    top: '42%',
    left: '4%',
    rotate: 5,
  },
  {
    id: 5,
    title: 'Proyecto 5',
    image:
      'https://images.unsplash.com/photo-1704428381485-fbdc84a7e58c?q=80&w=900&auto=format&fit=crop',
    alt: 'Oficina / estudio minimalista, tonos cálidos',
    size: 356,
    top: '38%',
    left: '32%',
    rotate: -5,
  },
  {
    id: 6,
    title: 'Proyecto 6',
    image:
      'https://images.unsplash.com/photo-1723750290151-164cb19ebab7?q=80&w=900&auto=format&fit=crop',
    alt: 'Comedor minimalista, tonos neutros',
    size: 369,
    top: '46%',
    left: '62%',
    rotate: 2,
  },
]

export default projects
