# giulia-portfolio (GA.GA) — Home

Vista Home del portafolio de Giulia (React + Vite + Framer Motion + React Router).

## Cómo correrlo en GitHub Codespaces

1. Subí esta carpeta a un repo (o descomprimí el zip dentro del repo que ya
   estés usando en Codespaces) y abrí el Codespace.
2. En la terminal del Codespace:
   ```bash
   cd giulia-portfolio
   npm install
   npm run dev
   ```
3. Codespaces va a detectar el puerto 5173 y te va a ofrecer abrirlo en el
   navegador ("Open in Browser") — o mirá la pestaña **Ports** si no aparece
   la notificación.
4. Para subir cambios: `git add . && git commit -m "mensaje" && git push`
   como ya venís haciendo con el proyecto de Manzur.

## Estructura

```
giulia-portfolio/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx          # entry point, monta BrowserRouter
    ├── App.jsx           # rutas: "/" (Home) y "/proyecto/:id" (placeholder)
    ├── index.css         # todos los estilos (watermark, nav, cartas, footer)
    ├── data/
    │   └── projects.js   # los 6 proyectos: imagen, tamaño, posición, rotación
    ├── components/
    │   ├── Watermark.jsx
    │   ├── Nav.jsx
    │   ├── FloatingCard.jsx
    │   └── Footer.jsx
    └── pages/
        ├── Home.jsx
        └── ProjectDetail.jsx   # placeholder, se construye en otro prompt
```

## Qué editar cuando lleguen los contenidos reales

- **Imágenes y títulos reales**: editá `src/data/projects.js`, un solo
  archivo para las 6 tarjetas.
- **Posición/tamaño/rotación de cada tarjeta**: mismos campos en
  `projects.js` (`top`, `left`, `size`, `rotate`).
- **Datos de contacto del footer**: `src/components/Footer.jsx`.

## Notas de implementación

- Las imágenes son placeholders de Unsplash (Unsplash License, gratuitas),
  cargadas directo por URL — no hace falta descargarlas.
- El cursor personalizado (punto blanco) solo aparece mientras el mouse
  está sobre una tarjeta; usa `mix-blend-mode: difference` para que se vea
  bien sobre cualquier imagen.
- El resto de las tarjetas baja opacidad al 45% cuando hay una en hover
  (se puede ajustar o quitar en `Home.jsx` / `FloatingCard.jsx` si no te
  convence el efecto).
- La ruta `/proyecto/:id` ya está conectada desde el click de cada tarjeta,
  pero la vista es un placeholder a propósito.
